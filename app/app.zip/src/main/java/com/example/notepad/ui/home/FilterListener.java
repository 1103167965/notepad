package com.example.notepad.ui.home;

import java.util.HashMap;
import java.util.List;

public interface FilterListener {
    public void getFilterData(List<HashMap<String,String>> list);
}
